module gr.uop {
    requires javafx.controls;
    exports gr.uop;
}